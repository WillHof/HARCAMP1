# InterCars

Designed for non-native english speakers looking for cars in the US, this application sports a clean, easy way to look up cars by make and model of their choice in the surrounding area. The page can be translated via a dropdown into a language they are more comfortable with, and they can login and save their searches if they find something they like. 
