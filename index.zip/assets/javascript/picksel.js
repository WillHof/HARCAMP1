$(function () {
    $('.selectpicker').selectpicker();
});